// Generated umbrella header for GoogleTagManager.

#import "TAGCustomFunction.h"
